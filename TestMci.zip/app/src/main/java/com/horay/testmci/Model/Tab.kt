package com.horay.testmci.Model

import androidx.fragment.app.Fragment

data class Tab(var name: String, val fragment: Fragment)
