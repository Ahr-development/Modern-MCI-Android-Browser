package com.horay.testmci.Model

data class Bookmark(val name: String, val url: String, var image: ByteArray? = null)
